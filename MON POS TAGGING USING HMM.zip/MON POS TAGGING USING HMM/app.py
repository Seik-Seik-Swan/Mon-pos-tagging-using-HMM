from flask import Flask
from flask import render_template,request,url_for
import nltk
from sklearn.model_selection import train_test_split
import numpy as np
import pandas as pd
import random
import time
import codecs
import json
from pos import *
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('base.html',active_page='home')

@app.route('/index')
def mike():
    return render_template('index.html',active_page='Mon POS Tagging')

@app.route('/history')
def history():
    return render_template('history.html',active_page='Mon History')
@app.route('/tag')
def tag():
    return render_template('tag.html',active_page='Mon Tag Set')
@app.route('/structure')
def structure():
    return render_template('structure.html',active_page='Mon Language Structure')

wordtag_dataset= []
# read the training data file #
input_file = codecs.open("mon.txt", mode = 'r', encoding="utf-8")
lines = input_file.readlines()
# pushing words of a line into a list #
for line in lines:
    line = line.rstrip()
    data = line.split(" ")
    # word,tag=data.split("/")
    wordtag_list=[]
    for wordtag in data:
        try:
            word,tag=wordtag.split("/")
            wordtag_list.append((word,tag))
        except:
            pass
    wordtag_dataset.append(wordtag_list)
        
    input_file.close()
# except IOError:
#     fo = codecs.open(output_file,mode = 'w',encoding="utf-8")
#     fo.write("File not found: {}".format(fin))
#     fo.close()
#     sys.exit()
# print(wordtag_dataset)

train_set,test_set =train_test_split(wordtag_dataset,train_size=0.8,test_size=0.2,random_state = 101)

# create list of train and test tagged words
train_tagged_words = [ tup for sent in train_set for tup in sent ]
test_tagged_words = [ tup for sent in test_set for tup in sent ]
# print(len(train_tagged_words))
# print(len(test_tagged_words))
# print(train_tagged_words)
#use set datatype to check how many unique tags are present in training data
tags = {tag for word,tag in train_tagged_words}
# print(len(tags))
# print(tags)
 
# check total words in vocabulary
vocab = {word for word,tag in train_tagged_words}

# compute Emission Probability
def word_given_tag(word, tag, train_bag = train_tagged_words):
    tag_list = [pair for pair in train_bag if pair[1]==tag]
    count_tag = len(tag_list)                           #total number of times the passed tag occurred in train_bag
    w_given_tag_list = [pair[0] for pair in tag_list if pair[0]==word]
    
    #now calculate the total number of times the passed word occurred as the passed tag.
    count_w_given_tag = len(w_given_tag_list)
    return (count_w_given_tag, count_tag)
# compute  Transition Probability
def t2_given_t1(t2, t1, train_bag = train_tagged_words):
    tags = [pair[1] for pair in train_bag]
    count_t1 = len([t for t in tags if t==t1])
    count_t2_t1 = 0
    for index in range(len(tags)-1):
        if tags[index]==t1 and tags[index+1] == t2:
            count_t2_t1 += 1
    return (count_t2_t1, count_t1)

# creating t x t transition matrix of tags, t= no of tags
# Matrix(i, j) represents P(jth tag after the ith tag)
 
tags_matrix = np.zeros((len(tags), len(tags)), dtype='float32')
for i, t1 in enumerate(list(tags)):
    for j, t2 in enumerate(list(tags)): 
        tags_matrix[i, j] = t2_given_t1(t2, t1)[0]/t2_given_t1(t2, t1)[1]
 
# print(tags_matrix)
# convert the matrix to a df for better readability
#the table is same as the transition table shown in section 3 of article
tags_df = pd.DataFrame(tags_matrix, columns = list(tags), index=list(tags))
#display(tags_df)

T = list(set([pair[1] for pair in train_tagged_words]))

def Viterbi(words, train_bag = train_tagged_words):
    state = []
    global T    
    
    for key, word in enumerate(words):
        #initialise list of probability column for a given observation
        p = [] 
        for tag in T:
            if key == 0:
                transition_p = tags_df.loc['NN', tag]
            else:
                transition_p = tags_df.loc[state[-1], tag]
                 
            # compute emission and state probabilities
            emission_p = word_given_tag(words[key], tag)[0]/word_given_tag(words[key], tag)[1]
            state_probability = emission_p * transition_p    
            p.append(state_probability)
             
        pmax = max(p)
        # getting state for which probability is maximum
        state_max = T[p.index(pmax)] 
        state.append(state_max)
    return list(zip(words, state))

@app.route('/result', methods=['POST'])
def result():
    global input_text
    global processed_text
    if request.method == 'POST':
        input_text = request.form.get('input_text', "")
        # Handle button actions based on which button was clicked
        if 'sentence_segmentation' in request.form:
            segmented_sentences=cut_into_sentence(input_text)
            processed_text = "\n".join(segmented_sentences)
        
    return render_template('index.html',input_text=input_text,processed_text=processed_text)
@app.route('/remove', methods=['POST'])
def remove():
    global remove_punctuation_sentnces
    if 'remove_punctuation':
        remove_punctuation_sentnces=remove_puntuations(processed_text)
    return render_template('index.html',input_text=input_text,processed_text=processed_text,remove_punctuation_sentnces=remove_punctuation_sentnces)
@app.route('/predict', methods=['POST'])
def predict():
    # Initialize the result container
    result = []
    lines=remove_punctuation_sentnces.split("\n")
        # Process each sentence
    for sentence in lines:
        words = sentence.split(" ")  # Split the sentence into words
        if words:
            # Use Viterbi algorithm to predict POS tags
            pos_tags = Viterbi(words)  # Replace with your Viterbi function
            # Format the result for this sentence
            formatted_sentence = ' '.join([f"{word}/{tag}" for word, tag in pos_tags])
            result.append(formatted_sentence)  # Add the formatted sentence to the result list
    
    # Join all sentences with newline for display
    result_text = '\n'.join(result)
    return render_template('index.html',input_text=input_text,processed_text=processed_text,remove_punctuation_sentnces=remove_punctuation_sentnces,result=result_text)




if __name__ == '__main__':
    app.run(debug=True,port=5000)