import nltk
import test
from nltk.tokenize import word_tokenize
import os
import re
text= r'mon_segment.txt'
with open(text, encoding='utf-8') as file:
    mon_text = file.read()

tokens = word_tokenize(mon_text)
corpus_file = r'testing_1.txt'
with open(corpus_file, "w", encoding="utf-8") as file:
    for token in tokens:
        if token=='။':
            pass
        else:
            word=token.replace("။","")  
            file.write(word + "\n")
mon_corpus= []
with open(corpus_file,'r',encoding='utf-8') as mon:
   mon_corpus = [line.strip() for line in mon]
corpus = set(mon_corpus)
#print(corpus)

#Segment input into sentences
def cut_into_sentence(string):
    seperator_Mon = r"။"
    seperator_English = r"!?"
    seperator = seperator_Mon+seperator_English
    if string:
        return [s.strip() for s in re.findall(r".*?[{0}]+".format(seperator), string+"\n")]
    # remove whitespace
def remove_spaces(text):
    # Define regex patterns for Myanmar and English characters
    mon_char_pattern = r"[\u1000-\u109F\uAA60-\uAA7F\uA9E0-\uA9FF]"
    english_char_pattern = r"[A-Za-z0-9]"
    
    # Split text into words
    words = text.split()
    
    # Initialize the result list
    result = []
    
    # Iterate through words and process spaces
    for i, word in enumerate(words):
        if re.search(mon_char_pattern, word):
            # If the word contains Myanmar characters, remove spaces
            result.append(word)
        else:
            # If the word contains English characters, add it with a space if it's not the first word
            if result and re.search(english_char_pattern, result[-1]):
                result.append(' ')
            result.append(word)
    
    # Join the result list into a single string
    return ''.join(result)
#Remove numbers from numbers
def remove_speials(input_string):
    remove_sp_char = ["!","?",",",".","。",":","/","@","$","^","*","(",")"]
#     mon_numbers = r"[၁၂၃၄၅၆၇၈၉၀]"
    unwanted_set = set(remove_sp_char)
    # Build a new string with only the wanted characters
    result = ''.join(char for char in input_string if char not in unwanted_set)
    return result
#Remove puntuations from
def remove_puntuations(input_string):
    puntuations = ["၊","။"]
    # Create a set of unwanted characters for faster lookup
    unwanted_set = set(puntuations)
    # Build a new string with only the wanted characters
    result = ''.join(char for char in input_string if char not in unwanted_set)
    return result
#Preprocessing Input Text
def data_cleaning(input_string ):
    remove_space = remove_spaces(input_string) 
    remove_puntuation  = remove_puntuations(remove_space)
    remove_special = remove_speials(remove_puntuation)
    unwanted_words=["!","?",",","၊",".","。","။",":","/","@","$","^","*","(",")"]
    remove_set = set(unwanted_words)
    filtered_string = ''.join(char for char in remove_special if char not in remove_set)
    print(remove_space)
    return filtered_string
# Sample Usage
# text = 'ညးကၠုင် နူ၊လဵုရော။Uni Ver'
# print(data_cleaning(text))

#Words Segmentation Through Maximum Marxhing Algorithm
# dic = ['abc', 'a', 'ab']
def max_match(sentence, dictionary):
    if not sentence:
        return ""
    for i in range(len(sentence), -1, -1):
        first_word = sentence[:i]
        first_word=''.join(first_word)
        
        remainder = sentence[i:]
        remainder=''.join(remainder)
        
        if first_word in dictionary:
            
            return first_word + "   " + max_match(remainder, dictionary)
    first_word = sentence[0]
    remainder = sentence[1:]
    return first_word + max_match(remainder, dictionary)
# result = max_match('ab',dic)
#  print(result)